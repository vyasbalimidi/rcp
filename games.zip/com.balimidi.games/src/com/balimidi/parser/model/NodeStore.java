package com.balimidi.parser.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author balimiv
 *
 */
public final class NodeStore {
	private static final Map<String, Node>			STORE		= new HashMap<>();
	private static final List<NodeStoreListener>	LISTENERS	= new ArrayList<>();

	private NodeStore() {
	}

	public static void addNode(final String filepath, final Node node) {
		boolean added = false;

		if (!STORE.containsKey(filepath)) {
			STORE.put(filepath, node);
			added = true;
		}

		if (added) {
			fireEvent(NodeStoreEvent.ADDED);
		}
	}

	public static Object[] getNodes() {
		return STORE.values().toArray();
	}

	public static void removeNode(final Node node) {
		String toRemove = null;

		for (final Entry<String, Node> entry : STORE.entrySet()) {
			if (entry.getValue() == node) {
				toRemove = entry.getKey();
				break;
			}
		}

		if (toRemove != null) {
			STORE.remove(toRemove);
			fireEvent(NodeStoreEvent.REMOVED);
		}
	}

	public static List<String> processedFiles() {
		return new ArrayList<>(STORE.keySet());
	}

	private static void fireEvent(final NodeStoreEvent event) {
		for (final NodeStoreListener listener : LISTENERS) {
			listener.changed(event);
		}
	}

	public static void addListener(final NodeStoreListener listener) {
		LISTENERS.add(listener);
	}

	public static void removeListener(final NodeStoreListener listener) {
		LISTENERS.remove(listener);
	}
}
