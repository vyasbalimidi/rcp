package com.balimidi.rest.model;

import java.util.List;
import java.util.Map;

/**
 * @author balimiv
 *
 */
public class Node {
	private String				occID;
	private Map<String, Object>	object;
	private Map<String, Object>	relation;

	private List<Node>		children;

	public Node() {
		// Default constructor
	}

	public String getOccID() {
		return occID;
	}

	public void setOccID(final String occID) {
		this.occID = occID;
	}

	public List<Node> getChildren() {
		return children;
	}

	public void setChildren(final List<Node> children) {
		this.children = children;
	}

	public Map<String, Object> getObject() {
		return object;
	}

	public void setObject(final Map<String, Object> object) {
		this.object = object;
	}

	public Map<String, Object> getRelation() {
		return relation;
	}

	public void setRelation(final Map<String, Object> relation) {
		this.relation = relation;
	}
}
