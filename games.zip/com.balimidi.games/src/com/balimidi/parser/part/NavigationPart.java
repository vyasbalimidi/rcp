package com.balimidi.parser.part;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.e4.core.contexts.IEclipseContext;
import org.eclipse.e4.ui.workbench.modeling.ESelectionService;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Tree;

import com.balimidi.parser.model.Node;
import com.balimidi.parser.model.NodeStore;
import com.balimidi.parser.model.NodeStoreEvent;
import com.balimidi.parser.part.listener.FileDropListener;
import com.balimidi.parser.part.provider.NavigationContentProvider;
import com.balimidi.parser.part.provider.NavigationLabelProvider;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class NavigationPart {
	@Inject
	private ESelectionService service;

	@PostConstruct
	public void createPartControl(final IEclipseContext context, final Composite parent) {
		// Add images to registry
		AppImages.register(context);

		// Create tree viewer
		final TreeViewer viewer = new TreeViewer(parent);
		final Tree tree = viewer.getTree();

		final int operations = DND.DROP_COPY | DND.DROP_MOVE;
		final Transfer[] transferTypes = new Transfer[] { FileTransfer.getInstance() };

		tree.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		viewer.setLabelProvider(new NavigationLabelProvider());
		viewer.setContentProvider(new NavigationContentProvider());
		viewer.addDropSupport(operations, transferTypes, new FileDropListener(viewer));

		// Selection to be broadcasted
		viewer.addSelectionChangedListener(event -> {

			final IStructuredSelection selection = viewer.getStructuredSelection();
			service.setSelection(selection.getFirstElement());
		});

		// Listener for add event
		NodeStore.addListener(event -> {

			final Display display = parent.getDisplay();
			display.asyncExec(() -> {
				if (event == NodeStoreEvent.ADDED) {
					viewer.setInput(NodeStore.getNodes());
				}
				viewer.refresh();
			});
		});

		// Listener for remove event
		tree.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(final KeyEvent event) {
				final ISelection selection = viewer.getSelection();

				if (!selection.isEmpty() && event.keyCode == 127) {
					final StructuredSelection ss = (StructuredSelection) selection;

					for (final Object obj : ss.toArray()) {
						NodeStore.removeNode((Node) obj);
					}
				}
			}
		});
	}
}
