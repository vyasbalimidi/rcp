package com.balimidi.parser.control;

import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.DropTargetAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.model.PersonSentence;
import com.balimidi.parser.util.RecordContext;

/**
 * @author balimiv
 *
 */
public final class RecordCanvas extends Canvas implements UISymbols {
	private final DropTarget	dropTarget;

	private int					width;
	private int					height;
	private GC					gc;

	private boolean				dropping;

	public RecordCanvas(final Composite parent) {
		super(parent, SWT.NONE);

		dropTarget = new DropTarget(this, DND.DROP_MOVE);
		addPaintListener(this::draw);
		configureDrop();
	}

	private void draw(final PaintEvent event) {
		final Rectangle clientArea = getClientArea();
		final int margin = 2;

		width = clientArea.width - 2 * margin;
		height = clientArea.height - 2 * margin;
		gc = event.gc;

		// Draw Rectangle
		gc.setBackground(dropping ? COLOR_INFO_BACKGROUND : COLOR_WHITE);
		gc.setForeground(COLOR_WIDGET_BORDER);

		gc.fillRectangle(margin, margin, width, height);
		gc.drawRectangle(margin, margin, width, height);

		// Draw text if user is dropping
		if (dropping) {
			final int x = width / 2 - 50;
			final int y = 20;

			gc.setFont(FONT_BOLD);
			gc.drawText("Drop record file here", x, y, true);
		}
	}

	private void configureDrop() {
		dropTarget.setTransfer(FileTransfer.getInstance());
		dropTarget.addDropListener(new DropTargetAdapter() {

			@Override
			public void dragEnter(final DropTargetEvent event) {
				showDropText(true);
			}

			@Override
			public void dragLeave(final DropTargetEvent event) {
				showDropText(false);
			}

			@Override
			public void drop(final DropTargetEvent event) {
				showDropText(false);

//				01  Vyas                Balimidi            28M
//				02  Ashwin              Kumar               29M
//				03  Gangaraj            Ramanna             30M
				if (event.data instanceof String[]) {
					final String[] files = (String[]) event.data;
					RecordContext.unmarshall(files[0], PersonSentence.class);
				}
			}
		});
	}

	private void showDropText(final boolean show) {
		dropping = show;
		redraw();
	}

	@Override
	public void dispose() {
		dropTarget.dispose();
		super.dispose();
	}

	@Override
	public Point computeSize(final int wHint, final int hHint, final boolean changed) {
		return new Point(width, height);
	}
}
