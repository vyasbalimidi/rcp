package com.balimidi.parser.registry;

import org.eclipse.e4.core.contexts.IEclipseContext;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import com.balimidi.parser.constant.Symbols;
import com.balimidi.parser.constant.UISymbols;

/**
 * @author balimiv
 *
 */
public final class AppImages {
	private static final Bundle			BUNDLE		= FrameworkUtil.getBundle(AppImages.class);
	private static final ImageRegistry	REGISTRY	= new ImageRegistry();

	private AppImages() {
		// Singelton
	}

	public static void register(final IEclipseContext context) {
		context.set(Symbols.IMAGE_REGISTRY_ID, REGISTRY);

		REGISTRY.put(UISymbols.IMG_XML, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_XML)));
		REGISTRY.put(UISymbols.IMG_TAG, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_TAG)));

		REGISTRY.put(UISymbols.IMG_RELOAD, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_RELOAD)));
		REGISTRY.put(UISymbols.IMG_CHECK, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_CHECK)));
		REGISTRY.put(UISymbols.IMG_BULL, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_BULL)));
		REGISTRY.put(UISymbols.IMG_COW, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_COW)));

		REGISTRY.put(UISymbols.IMG_EDITOR, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_EDITOR)));
		REGISTRY.put(UISymbols.IMG_GOOGLE, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_GOOGLE)));

		REGISTRY.put(UISymbols.IMG_PLAY, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_PLAY)));
		REGISTRY.put(UISymbols.IMG_PAUSE, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_PAUSE)));
		REGISTRY.put(UISymbols.IMG_APPLE, ImageDescriptor.createFromURL(BUNDLE.getEntry(UISymbols.IMG_APPLE)));
	}

	public static Image get(final String key) {
		return REGISTRY.get(key);
	}
}
