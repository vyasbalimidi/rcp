package com.balimidi.parser.constant;

/**
 * @author balimiv
 *
 */
public class Symbols {
	public static final String	PLUGIN_ID			= "com.balimidi.parser";
	public static final String	IMAGE_REGISTRY_ID	= "com.balimidi.parser.image-registry";

	public static final String	EMPTY				= "";
	public static final String	SPACE				= " ";
	public static final String	HYPHEN				= "-";
	public static final String	NEW_LINE			= "\n";

	public static final String	NUM_ZERO			= "0";

	public static final int		DIGITS				= 4;

	private Symbols() {
		// Singleton
	}
}
