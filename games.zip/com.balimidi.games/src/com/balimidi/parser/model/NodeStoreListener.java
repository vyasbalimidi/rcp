package com.balimidi.parser.model;

/**
 * @author balimiv
 *
 */
public interface NodeStoreListener {
	public void changed(final NodeStoreEvent event);
}
