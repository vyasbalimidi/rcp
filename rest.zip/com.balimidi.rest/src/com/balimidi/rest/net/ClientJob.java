package com.balimidi.rest.net;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.swt.widgets.Display;

import com.balimidi.rest.model.Symbols;
import com.google.gson.Gson;

/**
 * @author balimiv
 *
 */
public final class ClientJob<T> extends Job {
	private final String	endpoint;
	private final Class<T>	clazz;

	private T				response;

	private ClientJob(final String url, final Class<T> clazz) {
		super(Symbols.EMPTY);

		this.endpoint = url;
		this.clazz = clazz;
	}

	public static final <T> ClientJob<T> newRequest(final String url, final Class<T> clazz) {
		return new ClientJob<>(url, clazz);
	}

	@Override
	protected IStatus run(final IProgressMonitor monitor) {
		IStatus status = Status.OK_STATUS;

		try {
			final URL url = new URL(endpoint);
			final HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(Net.HTTP_GET);
			conn.setRequestProperty("Accept", "application/json");

			final int responseCode = conn.getResponseCode();

			if (responseCode == 200) {
				final InputStream stream = conn.getInputStream();
				final InputStreamReader reader = new InputStreamReader(stream);
				final Gson gson = new Gson();

				response = gson.fromJson(reader, clazz);
			} else {
				status = new Status(IStatus.ERROR, "com.balimidi.rest.net", "Response Code: " + responseCode);
			}

			conn.disconnect();
		} catch (final Exception exp) {
			status = Status.CANCEL_STATUS;
		}

		return status;
	}

	public void asyncGet(final ISuccess success) {
		asyncGet(success, null);
	}

	public void asyncGet(final ISuccess success, final IFailure failure) {
		addJobChangeListener(new JobChangeAdapter() {

			@Override
			public void done(final IJobChangeEvent event) {
				handleResult(success, failure, event);
			}
		});

		schedule();
	}

	private void handleResult(final ISuccess success, final IFailure failure, final IJobChangeEvent event) {
		final Display display = Display.getDefault();
		display.asyncExec(() -> {
			final IStatus result = event.getResult();

			if (result.isOK() && success != null) {
				success.run(response);
			} else if (failure != null) {
				failure.run();
			}
		});
	}
}
