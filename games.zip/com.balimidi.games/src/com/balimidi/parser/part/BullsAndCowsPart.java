package com.balimidi.parser.part;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import com.balimidi.parser.constant.Symbols;
import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.model.Trail;
import com.balimidi.parser.part.provider.GameLabelProvider;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class BullsAndCowsPart {
	private static final String[]		ITEMS;
	private static final int			COMBO_WIDTH;
	private static final List<String>	COLUMNS;

	static {
		ITEMS = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
		COMBO_WIDTH = 25;
		COLUMNS = new ArrayList<>();

		// Fill table column names
		COLUMNS.add("Trail");
		for (int index = 0; index < Symbols.DIGITS; index++) {
			COLUMNS.add("Digit - " + (index + 1));
		}
		COLUMNS.add("Bulls");
		COLUMNS.add("Cows");
	}

	private final List<Integer>	secretNumber;
	private final List<Combo>	combos;
	private final List<Trail>	trails;

	private int					trailCounter;

	private Button				checkButton;
	private Label				validationLabel;
	private GridData			validationGD;
	private TableViewer			viewer;

	public BullsAndCowsPart() {
		secretNumber = new ArrayList<>();
		combos = new ArrayList<>();
		trails = new ArrayList<>();

		trailCounter = 1;
	}

	@PostConstruct
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		// ------------- INPUT -------------
		final Composite buttonComposite = new Composite(parent, SWT.NONE);
		buttonComposite.setLayout(new GridLayout(Symbols.DIGITS + 2, false));
		buttonComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));

		// Reload button
		final Button reloadButton = new Button(buttonComposite, SWT.PUSH);
		reloadButton.setImage(AppImages.get(UISymbols.IMG_RELOAD));
		reloadButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent exp) {
				newGame();
			}
		});

		// Digits combo
		int comboIntialValue = 0;
		for (int i = 0; i < Symbols.DIGITS; i++) {
			final Combo combo = new Combo(buttonComposite, SWT.BORDER | SWT.READ_ONLY);

			combo.setLayoutData(new GridData(COMBO_WIDTH, SWT.DEFAULT));
			combo.setItems(ITEMS);
			combo.setText(String.valueOf(comboIntialValue++));

			combos.add(combo);
		}

		// Check button
		checkButton = new Button(buttonComposite, SWT.PUSH);
		checkButton.setImage(AppImages.get(UISymbols.IMG_CHECK));
		checkButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent exp) {
				checkClicked();
			}
		});

		// ------------- VALIDATION -------------
		validationLabel = new Label(parent, SWT.NONE);
		validationGD = new GridData(SWT.CENTER, SWT.FILL, true, false);

		validationLabel.setText("Duplicates are not allowed!");
		validationLabel.setLayoutData(validationGD);
		validationLabel.setFont(UISymbols.FONT_BOLD);
		validationLabel.setForeground(UISymbols.COLOR_DARK_RED);
		showValidationLabel(false);

		// ------------- TABLE -------------
		viewer = new TableViewer(parent, SWT.V_SCROLL | SWT.BORDER);
		final Table table = viewer.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		createTableColumns(table);

		viewer.setLabelProvider(new GameLabelProvider());
		viewer.setContentProvider(ArrayContentProvider.getInstance());
		viewer.setComparator(new ViewerComparator() {

			@Override
			public int compare(final Viewer viewer, final Object e1, final Object e2) {
				final Trail t1 = (Trail) e1;
				final Trail t2 = (Trail) e2;

				return t2.getAttempt() - t1.getAttempt();
			}
		});
		newGame();
	}

	private void showValidationLabel(final boolean show) {
		validationGD.exclude = !show;
		validationLabel.setVisible(show);
		validationLabel.getParent().layout();
	}

	private void createTableColumns(final Table table) {
		for (final String colName : COLUMNS) {
			final TableColumn column = new TableColumn(table, SWT.NONE);
			column.setResizable(true);
			column.setMoveable(true);

			if ("Bulls".equals(colName)) {
				column.setImage(AppImages.get(UISymbols.IMG_BULL));
				column.setWidth(30);
			} else if ("Cows".equals(colName)) {
				column.setImage(AppImages.get(UISymbols.IMG_COW));
				column.setWidth(30);
			} else {
				column.setText(colName);
				column.setWidth(60);
			}
		}
	}

	private void newGame() {
		checkButton.setEnabled(true);
		generateNewSecretNumber();

		trails.clear();
		trailCounter = 1;
		viewer.setInput(trails.toArray());
		validationLabel.setToolTipText(secretNumber.toString());
	}

	private void generateNewSecretNumber() {
		secretNumber.clear();
		final Random random = new Random();

		while (secretNumber.size() != Symbols.DIGITS) {
			final int digit = random.nextInt(10);

			if (!secretNumber.contains(digit)) {
				secretNumber.add(digit);
			}
		}
	}

	private void checkClicked() {
		final Trail trail = new Trail();
		final Set<String> valid = new HashSet<>();
		int bulls = 0;
		int cows = 0;

		for (int index = 0; index < Symbols.DIGITS; index++) {
			final Combo combo = combos.get(index);
			final Integer secretDigit = secretNumber.get(index);

			final String text = combo.getText();
			final int digit = Integer.parseInt(text);

			if (secretDigit == digit) {
				bulls++;
			} else if (secretNumber.contains(digit)) {
				cows++;
			}

			valid.add(text);
			trail.addDigit(digit);
		}

		final boolean isValid = valid.size() == Symbols.DIGITS;
		showValidationLabel(!isValid);

		if (isValid) {
			trail.setAttempt(trailCounter++);
			trail.setBulls(bulls);
			trail.setCows(cows);

			trails.add(trail);
			viewer.setInput(trails.toArray());
		}

		if (bulls == Symbols.DIGITS) {
			final Display display = Display.getDefault();
			final Shell shell = display.getActiveShell();

			checkButton.setEnabled(false);
			MessageDialog.openInformation(shell, "Congratulation", "You found the number");
		}
	}
}
