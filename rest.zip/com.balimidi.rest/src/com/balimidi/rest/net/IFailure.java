package com.balimidi.rest.net;

/**
 * @author balimiv
 *
 */
@FunctionalInterface
public interface IFailure {
	void run();
}
