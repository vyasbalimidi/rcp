package com.balimidi.parser.util;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import com.balimidi.parser.model.Node;

/**
 * @author balimiv
 *
 */
public final class XmlDefaultHandler extends DefaultHandler {
	private Node node;
	private String value;

	@Override
	public void startElement(final String uri, final String lName, final String qName, final Attributes attributes) {
		node = new Node(node, qName);
	}

	@Override
	public void endElement(final String uri, final String localName, final String qName) {
		node.setValue(value);

		final Node parent = node.getParent();
		node = parent != null ? parent : node;
	}

	@Override
	public void characters(final char ch[], final int start, final int length) {
		value = new String(ch, start, length).trim();
	}

	public Node getRoot() {
		return node;
	}
}
