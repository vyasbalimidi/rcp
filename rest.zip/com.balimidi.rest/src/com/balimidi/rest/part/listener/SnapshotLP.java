package com.balimidi.rest.part.listener;

import java.util.Map;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.balimidi.rest.model.Node;

/**
 * @author balimiv
 *
 */
public final class SnapshotLP extends LabelProvider {

	@Override
	public String getText(final Object element) {
		if (element instanceof Node) {
			final Node node = (Node) element;
			final Map<String, Object> object = node.getObject();
			final Object partNum = object.get("PartNumber");

			return partNum != null ? (String) partNum : (String) object.get("Class");
		}

		return null;
	}

	@Override
	public Image getImage(final Object element) {
		return null;
	}
}