package com.balimidi.rest.command;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.e4.ui.workbench.modeling.EPartService;

import com.balimidi.rest.part.SnapshotPart;

/**
 * @author balimiv
 *
 */
public class RefreshHandler {

	@Execute
	public void execute(final EPartService service) {
		final Object object = service.getActivePart().getObject();

		if (object instanceof SnapshotPart) {
			final SnapshotPart part = (SnapshotPart) object;
			part.reload();
		}
	}
}