package com.balimidi.rest.part.listener;

import org.eclipse.jface.viewers.ITreeContentProvider;

import com.balimidi.rest.model.Node;

/**
 * @author balimiv
 *
 */
public final class SnapshotCP implements ITreeContentProvider {
	private final ILazyContent content;

	public SnapshotCP(final ILazyContent content) {
		this.content = content;
	}

	@Override
	public Object[] getElements(final Object inputElement) {
		return inputElement instanceof Object[] ? (Object[]) inputElement : new Object[0];
	}

	@Override
	public Object[] getChildren(final Object parentElement) {
		if (parentElement instanceof Node) {
			final Node node = (Node) parentElement;

			if (content.canLoad(node)) {
				content.load(node);
			} else {
				return node.getChildren().toArray();
			}
		}

		return new Object[0];
	}

	@Override
	public Object getParent(final Object element) {
		return null;
	}

	@Override
	public boolean hasChildren(final Object element) {
		return true;
	}
}