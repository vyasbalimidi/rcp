package com.balimidi.parser.control.listener;

/**
 * @author balimiv
 *
 */
@FunctionalInterface
public interface SnakeListener {
	public void ate(final int size, final int speed);
}
