package com.balimidi.parser.part;

import javax.annotation.PostConstruct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.control.FiveInARowCanvas;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class FiveInARowPart {

	@PostConstruct
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(2, false));

		final FiveInARowCanvas canvas = new FiveInARowCanvas(parent);
		canvas.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, true));

		// Button Composite
		final Composite btnComposite = new Composite(parent, SWT.NONE);
		btnComposite.setLayout(new GridLayout(1, false));
		btnComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false));

		final Button btnReload = new Button(btnComposite, SWT.PUSH);
		btnReload.setImage(AppImages.get(UISymbols.IMG_RELOAD));
		btnReload.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent event) {
				canvas.reset();
			}
		});

		final Button btnOpenURL = new Button(btnComposite, SWT.PUSH);
		btnOpenURL.setImage(AppImages.get(UISymbols.IMG_GOOGLE));
		btnOpenURL.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent event) {
				Program.launch("https://www.google.co.in/");
			}
		});
	}
}
