package com.balimidi.parser.part.provider;

import org.eclipse.jface.viewers.ITreeContentProvider;

import com.balimidi.parser.model.Node;
import com.balimidi.parser.model.NodeStore;

/**
 * @author balimiv
 *
 */
public final class NavigationContentProvider implements ITreeContentProvider {

	@Override
	public Object[] getElements(final Object inputElement) {
		return NodeStore.getNodes();
	}

	@Override
	public Object[] getChildren(final Object parentElement) {
		if (parentElement instanceof Node) {
			final Node node = (Node) parentElement;
			return node.getChildren().toArray();
		}

		return new Object[0];
	}

	@Override
	public Object getParent(final Object element) {
		return null;
	}

	@Override
	public boolean hasChildren(final Object element) {
		if (element instanceof Node) {
			final Node node = (Node) element;
			return node.hasChildren();
		}

		return false;
	}

}