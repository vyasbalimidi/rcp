package com.balimidi.parser.util;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.stream.Stream;

import org.eclipse.core.runtime.Assert;

import com.balimidi.parser.constant.Symbols;
import com.balimidi.parser.model.Sentence;
import com.balimidi.parser.model.Word;

/**
 * @author balimiv
 *
 */
public final class RecordContext {
	private RecordContext() {
		// Singleton
	}

	/**
	 * @param objects array of objects
	 * @return string representing the record
	 */
	public static String marshall(final Object... objects) {
		Assert.isNotNull(objects);
		final StringBuilder builder = new StringBuilder();

		for (final Object object : objects) {
			final Class<?> clazz = object.getClass();

			try {
				if (clazz.isAnnotationPresent(Sentence.class)) {
					final Map<Word, String> words = new TreeMap<>((o1, o2) -> o1.index() - o2.index());

					// Segregate all the words in an order
					for (final Field field : clazz.getDeclaredFields()) {
						if (field.isAnnotationPresent(Word.class)) {
							final Word annotation = field.getAnnotation(Word.class);
							final Object value = field.get(object);
							final String str = value != null ? value.toString() : Symbols.EMPTY;

							words.put(annotation, str);
						}
					}

					// Create a sentence
					for (final Entry<Word, String> entry : words.entrySet()) {
						final Word word = entry.getKey();
						final int length = word.length();
						final String value = entry.getValue();

						if (value.length() >= length) {
							final String truncated = value.substring(0, length);
							builder.append(truncated);
						} else {
							builder.append(value);

							for (int index = value.length(); index < length; index++) {
								builder.append(Symbols.SPACE);
							}
						}
					}

					// Insert new line after every sentence
					builder.append(Symbols.NEW_LINE);
				}
			} catch (IllegalArgumentException | IllegalAccessException exp) {
				// Do nothing
			}
		}

		return builder.toString();
	}

	public static <T> List<T> unmarshall(final String fileName, final Class<T> clazz) {
		final List<T> objects = new ArrayList<>();

		try (final Stream<String> stream = Files.lines(Paths.get(fileName))) {
			stream.forEach(line -> {
				try {
					final T sentence = clazz.newInstance();

					for (final Field field : clazz.getDeclaredFields()) {
						if (field.isAnnotationPresent(Word.class)) {
							final Word word = field.getAnnotation(Word.class);
							field.getAnnotatedType().getType();
							field.set(sentence, line);
						}
					}

					objects.add(sentence);
				} catch (InstantiationException | IllegalAccessException exp) {
					// Do nothing
				}

			});
		} catch (final Exception exp) {
			// Do nothing
		}

		return objects;
	}
}
