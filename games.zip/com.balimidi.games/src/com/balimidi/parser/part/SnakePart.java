package com.balimidi.parser.part;

import javax.annotation.PostConstruct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.control.SnakeCanvas;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class SnakePart {

	@PostConstruct
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(2, false));

		final Composite scoreComposite = new Composite(parent, SWT.NONE);
		scoreComposite.setLayout(new GridLayout(1, false));
		scoreComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));

		final Composite btnComposite = new Composite(parent, SWT.NONE);
		btnComposite.setLayout(new GridLayout(1, false));
		btnComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 1, 2));

		final SnakeCanvas snakeCanvas = new SnakeCanvas(parent);
		snakeCanvas.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, true));

		// Score Composite
		final Label lblScore = new Label(scoreComposite, SWT.NONE);
		lblScore.setText("Score: 00");
		lblScore.setFont(UISymbols.FONT_BOLD);
		snakeCanvas.addSnakeListener((final int score) -> lblScore.setText("Score: " + score));

		// Button Composite
		final Button btnReload = new Button(btnComposite, SWT.PUSH);
		btnReload.setImage(AppImages.get(UISymbols.IMG_RELOAD));
		btnReload.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent event) {
				snakeCanvas.newGame();
				snakeCanvas.setFocus();
			}
		});

		final Button btnPause = new Button(btnComposite, SWT.TOGGLE);
		btnPause.setImage(AppImages.get(UISymbols.IMG_PAUSE));
		btnPause.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent event) {
				final boolean pause = btnPause.getSelection();
				final Image image = pause ? AppImages.get(UISymbols.IMG_PLAY) : AppImages.get(UISymbols.IMG_PAUSE);

				btnPause.setImage(image);
				snakeCanvas.setPause(pause);
				snakeCanvas.setFocus();
			}
		});
	}
}
