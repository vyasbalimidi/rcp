package com.balimidi.parser.part.provider;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.balimidi.parser.constant.Symbols;
import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.model.Trail;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class GameLabelProvider extends LabelProvider implements ITableLabelProvider {

	@Override
	public Image getColumnImage(final Object element, final int columnIndex) {
		final Trail trail = (Trail) element;

		if (columnIndex == 0) {
			if (trail.getBulls() > 0) {
				return AppImages.get(UISymbols.IMG_BULL);
			}
			if (trail.getCows() > 0) {
				return AppImages.get(UISymbols.IMG_COW);
			}
		}

		return null;
	}

	@Override
	public String getColumnText(final Object element, final int columnIndex) {
		final Trail trail = (Trail) element;
		Integer cell = null;

		if (columnIndex == 0) {
			cell = trail.getAttempt();
		} else if (columnIndex <= Symbols.DIGITS) {
			cell = trail.getDigits(columnIndex);
		} else if (columnIndex == Symbols.DIGITS + 1) {
			cell = trail.getBulls();
		} else if (columnIndex == Symbols.DIGITS + 2) {
			cell = trail.getCows();
		}

		return cell == null ? null : cell.toString();
	}
}
