package com.balimidi.parser.cache;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author balimiv
 *
 */
public final class AppCache {
	public static final AppCache	STORE	= new AppCache();

	private final List<File>		currentFiles;

	private AppCache() {
		currentFiles = new ArrayList<>();
	}

	public void processData(final Object data) {
		currentFiles.clear();

		if (data instanceof String) {
			addWhenFileExists((String) data);
		} else if (data instanceof String[]) {
			final String[] paths = (String[]) data;

			for (final String path : paths) {
				addWhenFileExists(path);
			}
		}
	}

	private void addWhenFileExists(final String path) {
		final File file = new File(path);

		if (file.exists()) {
			currentFiles.add(file);
		}
	}

	public List<File> getCurrentFiles() {
		return new ArrayList<>(currentFiles);
	}
}
