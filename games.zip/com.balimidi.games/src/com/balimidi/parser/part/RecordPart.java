package com.balimidi.parser.part;

import javax.annotation.PostConstruct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;

import com.balimidi.parser.control.RecordCanvas;

/**
 * @author balimiv
 *
 */
public final class RecordPart {

	@PostConstruct
	public void createPartControl(final Composite parent) {
		final RecordCanvas canvas = new RecordCanvas(parent);
		canvas.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
	}
}
