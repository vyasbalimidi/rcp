package com.balimidi.parser.part.provider;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.balimidi.parser.model.Node;

/**
 * @author balimiv
 *
 */
public final class DetailsLabelProvider extends LabelProvider implements ITableLabelProvider {

	@Override
	public String getColumnText(final Object element, final int columnIndex) {
		final Node node = (Node) element;
		return columnIndex == 0 ? node.getTag() : node.getValue();
	}

	@Override
	public Image getColumnImage(final Object element, final int columnIndex) {
		return null;
	}
}
