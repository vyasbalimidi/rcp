package com.balimidi.parser.util;

import java.io.File;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.balimidi.parser.model.Node;

/**
 * @author balimiv
 *
 */
public final class XmlParser {
	private XmlParser() {
	}

	public static Node parse(final File file) throws Exception {
		final SAXParserFactory factory = SAXParserFactory.newInstance();

		final SAXParser parser = factory.newSAXParser();
		final XmlDefaultHandler handler = new XmlDefaultHandler();

		parser.parse(file, handler);
		return handler.getRoot();
	}
}
