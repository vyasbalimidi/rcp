package com.balimidi.parser.control;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.control.listener.SwitchListener;

/**
 * @author balimiv
 *
 */
public final class SwitchCanvas extends Canvas implements UISymbols {
	private static final int			WIDTH	= 64;
	private static final int			HEIGHT	= 21;
	private static final int			MIDDLE	= WIDTH / 2;
	private static final int			OFFSET	= 5;

	private static final String			ON		= "ON";
	private static final String			OFF		= "OFF";

	private final List<SwitchListener>	listeners;
	private GC							gc;
	private boolean						selection;

	public SwitchCanvas(final Composite parent) {
		super(parent, SWT.NONE);

		listeners = new ArrayList<>();

		setBackground(COLOR_WHITE);
		addPaintListener(this::draw);
		addListener(SWT.MouseUp, this::mouseUp);
	}

	private void draw(final PaintEvent event) {
		gc = event.gc;

		drawRectangle();
		drawText();
		drawSelection();
	}

	private void drawRectangle() {
		final int height = HEIGHT - 1;

		gc.drawRectangle(0, 0, WIDTH - 1, height);
		gc.drawLine(MIDDLE, 0, MIDDLE, height);
	}

	private void drawText() {
		gc.drawText(ON, OFFSET, 3);
		gc.drawText(OFF, MIDDLE + OFFSET, 3);
	}

	private void drawSelection() {
		gc.setBackground(COLOR_WIDGET_NORMAL_SHADOW);

		if (selection) {
			gc.fillRectangle(MIDDLE + 1, 1, MIDDLE - 2, HEIGHT - 2);
		} else {
			gc.fillRectangle(1, 1, MIDDLE - 1, HEIGHT - 2);
		}
	}

	private void mouseUp(final Event event) {
		if (event.button == 1) {
			selection = !selection;
			redraw();
			fireSwitchListener();
		}
	}

	private void fireSwitchListener() {
		for (final SwitchListener listener : listeners) {
			listener.switched();
		}
	}

	public void setSelection(final boolean selection) {
		this.selection = selection;
		redraw();
		fireSwitchListener();
	}

	public boolean isSelection() {
		return selection;
	}

	public void addSwitchListener(final SwitchListener listener) {
		listeners.add(listener);
	}

	public void removeSwitchListener(final SwitchListener listener) {
		listeners.remove(listener);
	}

	@Override
	public Point computeSize(final int wHint, final int hHint, final boolean changed) {
		return new Point(WIDTH, HEIGHT);
	}
}
