package com.balimidi.parser.part;

import javax.annotation.PostConstruct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

import com.balimidi.parser.model.record.PersonSentence;
import com.balimidi.parser.model.record.Record;

/**
 * @author balimiv
 *
 */
public final class RecordPart {

	@PostConstruct
	public void createPartControl(final Composite parent) {
		final PersonSentence p1 = new PersonSentence();
		p1.id = "01";
		p1.firstname = "Vyas";
		p1.lastname = "Balimidi";
		p1.gender = "M";
		p1.age = 28;

		final PersonSentence p2 = new PersonSentence();
		p2.id = "02";
		p2.firstname = "Ashwin";
		p2.lastname = "Kumar";
		p2.gender = "M";
		p2.age = 29;

		final PersonSentence p3 = new PersonSentence();
		p3.id = "03";
		p3.firstname = "Gamgaraj";
		p3.lastname = "Ramanna";
		p3.gender = "M";
		p3.age = 30;

		final Text text = new Text(parent, SWT.BORDER | SWT.MULTI | SWT.READ_ONLY);
		text.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		text.setText(Record.marshall(p1, p2, p3));
	}
}
