package com.balimidi.rest.model;

/**
 * @author balimiv
 *
 */
public interface Symbols {
	String EMPTY = "";
}
