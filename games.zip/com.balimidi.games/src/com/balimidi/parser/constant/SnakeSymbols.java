package com.balimidi.parser.constant;

/**
 * @author balimiv
 *
 */
public interface SnakeSymbols {
	int	REFRESH_RATE	= 250;
	int	INITIAL_SIZE	= 3;

	int	PLAY_AREA		= 300;
	int	SCALE			= 10;

	int	V_CENTER		= PLAY_AREA / (2 * SCALE);
	int	APPLE_LIMITS	= (PLAY_AREA - SCALE) / SCALE;
}
