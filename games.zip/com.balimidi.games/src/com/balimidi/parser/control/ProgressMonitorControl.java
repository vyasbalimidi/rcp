package com.balimidi.parser.control;

import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.ProgressProvider;
import org.eclipse.e4.ui.di.UISynchronize;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;

import com.balimidi.parser.constant.Symbols;

public final class ProgressMonitorControl {
	private final UISynchronize			sync;
	private final AppProgressMonitor	monitor;

	private Label						title;
	private Label						subtitle;
	private ProgressBar					progressBar;

	@Inject
	public ProgressMonitorControl(final UISynchronize synchronize) {
		sync = Objects.requireNonNull(synchronize);
		monitor = new AppProgressMonitor();
	}

	@PostConstruct
	public void createToolControl(final Composite parent) {
		parent.setLayout(new GridLayout(3, false));

		title = new Label(parent, SWT.NONE);
		title.setLayoutData(new GridData(200, SWT.DEFAULT));

		subtitle = new Label(parent, SWT.NONE);
		subtitle.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		progressBar = new ProgressBar(parent, SWT.SMOOTH);

		Job.getJobManager().setProgressProvider(new ProgressProvider() {

			@Override
			public IProgressMonitor createMonitor(final Job job) {
				return monitor;
			}
		});
	}

	private final class AppProgressMonitor extends NullProgressMonitor {

		@Override
		public void beginTask(final String name, final int totalWork) {
			sync.syncExec(() -> {
				title.setText(name);
				progressBar.setSelection(0);
				progressBar.setMaximum(totalWork);
			});
		}

		@Override
		public void subTask(final String name) {
			sync.asyncExec(() -> subtitle.setText(name));
		}

		@Override
		public void worked(final int work) {
			sync.syncExec(() -> progressBar.setSelection(progressBar.getSelection() + work));
		}

		@Override
		public void done() {
			sync.syncExec(() -> {
				progressBar.setSelection(0);
				title.setText(Symbols.EMPTY);
				subtitle.setText(Symbols.EMPTY);
			});
		}
	}
}