package com.balimidi.parser.control;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.DropTargetAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.model.PersonSentence;
import com.balimidi.parser.model.Word;
import com.balimidi.parser.util.RecordContext;

/**
 * @author balimiv
 *
 */
public final class RecordCanvas extends Canvas implements UISymbols {
	private final DropTarget			dropTarget;
	private final List<PersonSentence>	sentences;

	private int							width;
	private int							height;
	private GC							gc;

	private boolean						dropping;

	public RecordCanvas(final Composite parent) {
		super(parent, SWT.NO_BACKGROUND);

		dropTarget = new DropTarget(this, DND.DROP_MOVE);
		sentences = new ArrayList<>();

		addPaintListener(this::draw);
		configureDrop();
	}

	private void draw(final PaintEvent event) {
		final Rectangle clientArea = getClientArea();
		width = clientArea.width;
		height = clientArea.height;

		// Create image and GC for double buffering
		final Image image = new Image(DISPLAY, width, height);
		gc = new GC(image);

		// Draw
		drawRectangle();
		drawDropRecordText();
		drawLines();
		drawSentences();

		// Display image on canvas
		event.gc.drawImage(image, 0, 0);

		// Dispose created resources
		image.dispose();
		gc.dispose();
	}

	private void drawRectangle() {
		gc.setBackground(dropping ? COLOR_INFO_BACKGROUND : COLOR_WHITE);

		gc.fillRectangle(0, 0, width, height);
		gc.drawRectangle(0, 0, width - 1, height - 1);
	}

	private void drawDropRecordText() {
		if (!dropping) {
			return;
		}

		gc.setFont(FONT_BOLD);
		gc.setForeground(COLOR_DARK_RED);
		gc.drawText("Drop record file here", width / 2 - 50, 25);
	}

	private void drawLines() {
		if (dropping || sentences.isEmpty()) {
			return;
		}

		gc.setForeground(COLOR_GRAY);

		// Rows
		for (int index = 0; index <= sentences.size(); index++) {
			final int posY = index * 15;
			gc.drawLine(0, posY, width, posY);
		}

		// Columns
		for (final Field field : PersonSentence.class.getDeclaredFields()) {
			final Word word = field.getAnnotation(Word.class);
			final int begin = word.begin();
			final int end = word.end();

			final int minSize = (end - begin) == 1 ? end + 1 : end;
			final int posX = minSize * 10;

			gc.drawLine(posX, 0, posX, height);
		}
	}

	private void drawSentences() {
		if (dropping || sentences.isEmpty()) {
			return;
		}

		gc.setForeground(COLOR_BLACK);

		// Data
		for (int index = 0; index < sentences.size(); index++) {
			final PersonSentence sentence = sentences.get(index);
			final int posY = index * 15;

			for (final Field field : sentence.getClass().getDeclaredFields()) {
				final int posX = field.getAnnotation(Word.class).begin() * 10 + 5;

				try {
					final String object = field.get(sentence).toString();
					gc.drawText(object, posX, posY, true);
				} catch (final Exception exp) {
					// Do nothing
				}
			}
		}
	}

	private void configureDrop() {
		dropTarget.setTransfer(FileTransfer.getInstance());
		dropTarget.addDropListener(new DropTargetAdapter() {

			@Override
			public void dragEnter(final DropTargetEvent event) {
				showDropText(true);
			}

			@Override
			public void dragLeave(final DropTargetEvent event) {
				showDropText(false);
			}

			@Override
			public void drop(final DropTargetEvent event) {
				showDropText(false);

				if (event.data instanceof String[]) {
					final String[] files = (String[]) event.data;
					final List<PersonSentence> unmarshall = RecordContext.unmarshall(files[0], PersonSentence.class);

					if (!unmarshall.isEmpty()) {
						sentences.clear();
						sentences.addAll(unmarshall);
						redraw();
					} else {
						invalidRecord();
					}
				}
			}
		});
	}

	private void showDropText(final boolean show) {
		dropping = show;
		redraw();
	}

	private void invalidRecord() {
		final Display display = Display.getDefault();
		final Shell shell = display.getActiveShell();

		MessageDialog.openError(shell, "Error occurred", "Dropped file may be corrupted or not a valid record");
	}

	@Override
	public void dispose() {
		dropTarget.dispose();
		super.dispose();
	}

	@Override
	public Point computeSize(final int wHint, final int hHint, final boolean changed) {
		return new Point(width, height);
	}
}
