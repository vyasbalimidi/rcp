package com.balimidi.parser.control;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.DropTargetAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.model.PersonSentence;
import com.balimidi.parser.util.RecordContext;

/**
 * @author balimiv
 *
 */
public final class RecordCanvas extends Canvas implements UISymbols {
	private final DropTarget			dropTarget;
	private final List<PersonSentence>	sentences;

	private int							width;
	private int							height;
	private GC							gc;

	private boolean						dropping;

	public RecordCanvas(final Composite parent) {
		super(parent, SWT.NO_BACKGROUND);

		dropTarget = new DropTarget(this, DND.DROP_MOVE);
		sentences = new ArrayList<>();

		addPaintListener(this::draw);
		configureDrop();
	}

	private void draw(final PaintEvent event) {
		final Rectangle clientArea = getClientArea();
		width = clientArea.width;
		height = clientArea.height;

		// Create image and GC for double buffering
		final Image image = new Image(DISPLAY, width, height);
		gc = new GC(image);

		// Draw
		drawRectangle();
		drawDropRecordText();
		drawSentences();

		// Display image on canvas
		event.gc.drawImage(image, 0, 0);

		// Dispose created resources
		image.dispose();
		gc.dispose();
	}

	private void drawRectangle() {
		if (dropping) {
			gc.setBackground(COLOR_INFO_BACKGROUND);
		} else if (!sentences.isEmpty()) {
			gc.setBackground(COLOR_GREEN);
		} else {
			gc.setBackground(COLOR_WHITE);
		}

		gc.fillRectangle(0, 0, width, height);
		gc.drawRectangle(0, 0, width - 1, height - 1);
	}

	private void drawDropRecordText() {
		if (dropping) {
			gc.setFont(FONT_BOLD);
			gc.setForeground(COLOR_BLUE);
			gc.drawText("Drop record file here", width / 2 - 50, 25);
		}
	}

	private void drawSentences() {
		if (!dropping && !sentences.isEmpty()) {
			int posY = 25;

			for (final PersonSentence sentence : sentences) {
				final String str = sentence.toString();

				gc.setFont(null);
				gc.setForeground(COLOR_BLACK);

				gc.drawText(str, 10, posY, true);
				gc.drawLine(0, posY, width, posY);
				posY = posY + gc.textExtent(str).y;
			}

			gc.drawLine(0, posY, width, posY);
		}
	}

	private void configureDrop() {
		dropTarget.setTransfer(FileTransfer.getInstance());
		dropTarget.addDropListener(new DropTargetAdapter() {

			@Override
			public void dragEnter(final DropTargetEvent event) {
				showDropText(true);
			}

			@Override
			public void dragLeave(final DropTargetEvent event) {
				showDropText(false);
			}

			@Override
			public void drop(final DropTargetEvent event) {
				showDropText(false);

				if (event.data instanceof String[]) {
					final String[] files = (String[]) event.data;
					sentences.clear();

					sentences.addAll(RecordContext.unmarshall(files[0], PersonSentence.class));
					redraw();
				}
			}
		});
	}

	private void showDropText(final boolean show) {
		dropping = show;
		redraw();
	}

	@Override
	public void dispose() {
		dropTarget.dispose();
		super.dispose();
	}

	@Override
	public Point computeSize(final int wHint, final int hHint, final boolean changed) {
		return new Point(width, height);
	}
}
