package com.balimidi.rest.net;

/**
 * @author balimiv
 *
 */
public interface Net {
	String	HTTP_GET		= "GET";
	String	HTTP_POST		= "POST";
	String	HTTP_PUT		= "PUT";

	String	DOMAIN			= "http://localhost:9250";

	String	SNAPSHOTS_ALL	= DOMAIN + "/snapshots";
	String	SNAPSHOT		= DOMAIN + "/snapshots/Zm1zcl8xZDQ4YjQ5NmI1YTAxMWU4YWQ2ZDAwNTA1NjAwMTBjYy0tLS0=";
}
