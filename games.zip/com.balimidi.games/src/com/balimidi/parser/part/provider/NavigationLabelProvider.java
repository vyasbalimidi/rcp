package com.balimidi.parser.part.provider;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.model.Node;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class NavigationLabelProvider extends LabelProvider {

	@Override
	public String getText(final Object element) {
		if (element instanceof Node) {
			final Node node = (Node) element;
			return node.getTag();
		}

		return null;
	}

	@Override
	public Image getImage(final Object element) {
		if (element instanceof Node) {
			final Node node = (Node) element;
			return node.getParent() == null ? AppImages.get(UISymbols.IMG_XML) : AppImages.get(UISymbols.IMG_TAG);
		}
		return null;
	}
}