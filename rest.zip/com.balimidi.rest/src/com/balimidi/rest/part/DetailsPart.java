package com.balimidi.rest.part;

import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.e4.core.di.annotations.Optional;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.jface.resource.FontRegistry;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import com.balimidi.rest.model.Node;

/**
 * @author balimiv
 *
 */
public class DetailsPart {
	private static final Font	BOLD	= new FontRegistry().getBold("Arial");
	private static final Font	ITALIC	= new FontRegistry().getItalic("Arial");

	private Composite			objContainer;
	private Composite			relContainer;

	private Composite			objComposite;
	private Composite			relComposite;

	@PostConstruct
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		// ----------- OBJECT -----------
		final Label objLbl = new Label(parent, SWT.NONE);
		objLbl.setFont(BOLD);
		objLbl.setText("Object Information");
		objLbl.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));

		final Label objSeparator = new Label(parent, SWT.SEPARATOR | SWT.HORIZONTAL);
		objSeparator.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		objContainer = new Composite(parent, SWT.NONE);
		objContainer.setLayout(new GridLayout(1, false));
		objContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		recreateObjComposite();

		// ----------- RELATION -----------
		final Label relLbl = new Label(parent, SWT.NONE);
		relLbl.setFont(BOLD);
		relLbl.setText("Relation Information");
		relLbl.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));

		final Label relSeparator = new Label(parent, SWT.SEPARATOR | SWT.HORIZONTAL);
		relSeparator.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		relContainer = new Composite(parent, SWT.NONE);
		relContainer.setLayout(new GridLayout(1, false));
		relContainer.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		recreateRelComposite();
	}

	private void recreateObjComposite() {
		if (objComposite != null) {
			objComposite.dispose();
		}

		objComposite = new Composite(objContainer, SWT.NONE);
		objComposite.setLayout(new GridLayout(2, false));
		objComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
	}

	private void recreateRelComposite() {
		if (relComposite != null) {
			relComposite.dispose();
		}

		relComposite = new Composite(relContainer, SWT.NONE);
		relComposite.setLayout(new GridLayout(2, false));
		relComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
	}

	@Inject
	public void setTodo(@Optional @Named(IServiceConstants.ACTIVE_SELECTION) final Node node) {
		if (node != null) {
			final Map<String, Object> object = node.getObject();
			final Map<String, Object> relation = node.getRelation();

			// ----------- OBJECT -----------
			if (object != null) {
				recreateObjComposite();

				for (final Entry<String, Object> entry : object.entrySet()) {
					final Label keyLbl = new Label(objComposite, SWT.NONE);
					keyLbl.setText(entry.getKey());

					final Label valLbl = new Label(objComposite, SWT.NONE);
					valLbl.setFont(ITALIC);
					valLbl.setText((String) entry.getValue());
				}

				objContainer.layout();
			}

			// ----------- RELATION -----------
			if (relation != null) {
				recreateRelComposite();

				for (final Entry<String, Object> entry : relation.entrySet()) {
					final Label keyLbl = new Label(relComposite, SWT.NONE);
					keyLbl.setText(entry.getKey() + ":");

					final Label valLbl = new Label(relComposite, SWT.NONE);
					valLbl.setFont(ITALIC);
					valLbl.setText((String) entry.getValue());
				}

				relContainer.layout();
			}

		}
	}
}