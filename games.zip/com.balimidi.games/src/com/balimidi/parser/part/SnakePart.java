package com.balimidi.parser.part;

import java.text.MessageFormat;

import javax.annotation.PostConstruct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;

import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.control.SnakeCanvas;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class SnakePart {
	private static final String SCORE = "Score: {0}\tSpeed: {1}";

	@PostConstruct
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(2, false));

		final Composite scoreComposite = new Composite(parent, SWT.NONE);
		scoreComposite.setLayout(new GridLayout(1, false));
		scoreComposite.setLayoutData(new GridData(SWT.CENTER, SWT.FILL, true, false));

		final Composite btnComposite = new Composite(parent, SWT.NONE);
		btnComposite.setLayout(new GridLayout(1, false));
		btnComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 1, 2));

		final SnakeCanvas snakeCanvas = new SnakeCanvas(parent);
		snakeCanvas.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, true));

		// Score Composite
		final Label lblScore = new Label(scoreComposite, SWT.NONE);
		lblScore.setFont(UISymbols.FONT_BOLD);
		lblScore.setText("Score: 00		Speed: 000");
		snakeCanvas.addSnakeListener((score, speed) -> lblScore.setText(MessageFormat.format(SCORE, score, speed)));

		// Button Composite
		final Button btnReload = new Button(btnComposite, SWT.PUSH);
		btnReload.setImage(AppImages.get(UISymbols.IMG_RELOAD));
		btnReload.addListener(SWT.Selection, event -> {
			snakeCanvas.newGame();
			snakeCanvas.setFocus();
		});

		final Button btnPause = new Button(btnComposite, SWT.TOGGLE);
		btnPause.setImage(AppImages.get(UISymbols.IMG_PAUSE));
		btnPause.addListener(SWT.Selection, event -> {
			final boolean pause = btnPause.getSelection();
			final Image image = pause ? AppImages.get(UISymbols.IMG_PLAY) : AppImages.get(UISymbols.IMG_PAUSE);

			btnPause.setImage(image);
			snakeCanvas.setPause(pause);
			snakeCanvas.setFocus();
		});

		btnPause.setSelection(true);
		btnPause.notifyListeners(SWT.Selection, new Event());
	}
}
