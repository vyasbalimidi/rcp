package com.balimidi.rest.net;

/**
 * @author balimiv
 *
 */
@FunctionalInterface
public interface ISuccess {
	void run(Object object);
}
