package com.balimidi.parser.control.listener;

/**
 * @author balimiv
 *
 */
@FunctionalInterface
public interface SwitchListener {
	public void switched();
}
