package com.balimidi.parser.constant;

import org.eclipse.jface.resource.FontRegistry;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Display;

/**
 * @author balimiv
 *
 */
public interface UISymbols {
	Display			DISPLAY						= Display.getCurrent();
	FontRegistry	FONT_REGISTRY				= new FontRegistry();

	Font			FONT_BOLD					= FONT_REGISTRY.getBold("Arial");
	Color			COLOR_WIDGET_NORMAL_SHADOW	= DISPLAY.getSystemColor(SWT.COLOR_WIDGET_NORMAL_SHADOW);
	Color			COLOR_INFO_BACKGROUND		= DISPLAY.getSystemColor(SWT.COLOR_INFO_BACKGROUND);

	Color			COLOR_WHITE					= DISPLAY.getSystemColor(SWT.COLOR_WHITE);
	Color			COLOR_BLACK					= DISPLAY.getSystemColor(SWT.COLOR_BLACK);
	Color			COLOR_RED					= DISPLAY.getSystemColor(SWT.COLOR_RED);
	Color			COLOR_DARK_RED				= DISPLAY.getSystemColor(SWT.COLOR_DARK_RED);
	Color			COLOR_BLUE					= DISPLAY.getSystemColor(SWT.COLOR_BLUE);
	Color			COLOR_GREEN					= DISPLAY.getSystemColor(SWT.COLOR_GREEN);
	Color			COLOR_DARK_GRAY				= DISPLAY.getSystemColor(SWT.COLOR_GRAY);

	String			IMG_XML						= "icons/xml.png";
	String			IMG_TAG						= "icons/tag.png";

	String			IMG_RELOAD					= "icons/reload.png";
	String			IMG_CHECK					= "icons/check.png";
	String			IMG_BULL					= "icons/bull.png";
	String			IMG_COW						= "icons/cow.png";

	String			IMG_EDITOR					= "icons/editor.png";
	String			IMG_GOOGLE					= "icons/google.png";

	String			IMG_PLAY					= "icons/play.png";
	String			IMG_PAUSE					= "icons/pause.png";
	String			IMG_APPLE					= "icons/apple.png";
}
