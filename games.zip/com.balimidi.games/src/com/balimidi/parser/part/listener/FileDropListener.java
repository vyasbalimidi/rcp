package com.balimidi.parser.part.listener;

import java.io.File;
import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerDropAdapter;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.TransferData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.balimidi.parser.cache.AppCache;
import com.balimidi.parser.job.ParserJob;

/**
 * @author balimiv
 *
 */
public final class FileDropListener extends ViewerDropAdapter {

	public FileDropListener(final Viewer viewer) {
		super(viewer);
	}

	@Override
	public boolean performDrop(final Object data) {
		// Identify all the valid file paths
		AppCache.STORE.processData(data);
		final List<File> files = AppCache.STORE.getCurrentFiles();

		// Parse all dropped files
		final ParserJob job = new ParserJob(files);
		job.addJobChangeListener(new JobChangeAdapter() {

			@Override
			public void done(final IJobChangeEvent event) {
				jobCompleted(event);
			}
		});
		job.setUser(true);
		job.schedule();

		return true;
	}

	protected void jobCompleted(final IJobChangeEvent event) {
		final Display display = Display.getDefault();
		display.asyncExec(() -> {
			final IStatus result = event.getResult();

			// Show error message if any file failed to parse
			if (!result.isOK()) {
				final Shell shell = display.getActiveShell();
				MessageDialog.openError(shell, "Failed to parse", result.getMessage());
			}
		});
	}

	@Override
	public boolean validateDrop(final Object target, final int operation, final TransferData transferType) {
		return FileTransfer.getInstance().isSupportedType(transferType);
	}
}