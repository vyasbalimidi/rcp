package com.balimidi.parser.model;

/**
 * @author balimiv
 *
 */
public final class PersonSentence {
	@Word(begin = 0, end = 4)
	public String	id;

	@Word(begin = 4, end = 24)
	public String	firstname;

	@Word(begin = 24, end = 44)
	public String	lastname;

	@Word(begin = 44, end = 46)
	public int		age;

	@Word(begin = 46, end = 47)
	public String	gender;

	@Override
	public String toString() {
		return id + firstname + lastname + age + gender;
	}
}
