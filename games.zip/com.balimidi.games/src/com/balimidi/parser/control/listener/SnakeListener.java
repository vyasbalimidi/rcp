package com.balimidi.parser.control.listener;

/**
 * @author balimiv
 *
 */
@FunctionalInterface
public interface SnakeListener {
	public void score(final int size);
}
