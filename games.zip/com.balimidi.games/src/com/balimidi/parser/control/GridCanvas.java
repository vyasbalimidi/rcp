package com.balimidi.parser.control;

import java.text.MessageFormat;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;

import com.balimidi.parser.constant.UISymbols;

/**
 * @author balimiv
 *
 */
public final class GridCanvas extends Canvas implements UISymbols {
	private static final int	LEFT_BUTTON	= 1;

	private static final int	WIDTH		= 240;
	private static final int	HEIGHT		= WIDTH;
	private static final int	NUM_OF_GRID	= 10;

	private static final int	GRID_LENGTH	= WIDTH / NUM_OF_GRID;
	private static final int	ORIGIN		= GRID_LENGTH / 2;

	private int[][]				board;
	private int					player;

	private GC					gc;

	public GridCanvas(final Composite parent) {
		super(parent, SWT.NONE);

		board = new int[NUM_OF_GRID][NUM_OF_GRID];
		player = 1;

		setBackground(COLOR_WHITE);
		addPaintListener(this::draw);
		addListener(SWT.MouseUp, this::mouseUp);
	}

	private void draw(final PaintEvent event) {
		gc = event.gc;

		drawRectangle();
		drawGrid();
		drawSelections();
	}

	private void drawRectangle() {
		final int side = WIDTH - 1;
		gc.drawRectangle(0, 0, side, side);
	}

	private void drawGrid() {
		gc.setForeground(COLOR_BLACK);

		for (int i = 1; i <= NUM_OF_GRID; i++) {
			final int grid = GRID_LENGTH * i;

			gc.drawLine(grid, 0, grid, HEIGHT);
			gc.drawLine(0, grid, WIDTH, grid);
		}
	}

	private void drawSelections() {
		for (int row = 0; row < board.length; row++) {
			for (int col = 0; col < board[row].length; col++) {
				final int selected = board[row][col];

				if (selected == 1 || selected == 2) {
					final Color color = selected == 1 ? COLOR_RED : COLOR_BLUE;
					gc.setBackground(color);

					final int x = GRID_LENGTH * row + 6;
					final int y = GRID_LENGTH * col + 6;

					gc.fillOval(x, y, ORIGIN, ORIGIN);
				}
			}
		}
	}

	private void mouseUp(final Event event) {
		if (event.button == LEFT_BUTTON) {
			final int posX = event.x / GRID_LENGTH;
			final int posY = event.y / GRID_LENGTH;

			if (board[posX][posY] != 1 && board[posX][posY] != 2) {
				board[posX][posY] = player;

				redraw();
				if (checkIfGameover(posX, posY)) {
					showGameWon();
				}

				player = player == 1 ? 2 : 1;
			}
		}
	}

	private boolean checkIfGameover(final int posX, final int posY) {
		if (checkHorizontally(posX)) {
			return true;
		}

		return checkVertically(posY);
	}

	private boolean checkHorizontally(final int posX) {
		int count = 0;

		for (int index = 0; index < NUM_OF_GRID; index++) {
			if (board[posX][index] == player) {
				count++;

				if (count == 5) {
					return true;
				}
			} else {
				count = 0;
			}
		}

		return false;
	}

	private boolean checkVertically(final int posY) {
		int count = 0;

		for (int index = 0; index < NUM_OF_GRID; index++) {
			if (board[index][posY] == player) {
				count++;

				if (count == 5) {
					return true;
				}
			} else {
				count = 0;
			}
		}

		return false;
	}

	private void showGameWon() {
		final Display display = Display.getDefault();
		final Shell shell = display.getActiveShell();

		setEnabled(false);
		MessageDialog.openInformation(shell, "Congratulation", MessageFormat.format("Player {0} has won", player));
	}

	public void reset() {
		board = new int[NUM_OF_GRID][NUM_OF_GRID];
		player = 1;

		setEnabled(true);
		redraw();
	}

	@Override
	public Point computeSize(final int wHint, final int hHint, final boolean changed) {
		return new Point(WIDTH, HEIGHT);
	}
}
