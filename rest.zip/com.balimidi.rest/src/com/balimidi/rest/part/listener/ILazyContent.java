package com.balimidi.rest.part.listener;

/**
 * @author balimiv
 *
 */
public interface ILazyContent<T> {
	void load(T element);

	boolean canLoad(T element);
}
