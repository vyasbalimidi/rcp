package com.balimidi.parser.control;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;

import com.balimidi.parser.constant.SnakeSymbols;
import com.balimidi.parser.constant.UISymbols;
import com.balimidi.parser.control.listener.SnakeListener;
import com.balimidi.parser.registry.AppImages;

/**
 * @author balimiv
 *
 */
public final class SnakeCanvas extends Canvas implements SnakeSymbols, UISymbols {
	private static final List<Integer>			ALLOWED_KEYS;
	private static final Map<Integer, Integer>	OPPOSITE_KEYS;
	static {
		ALLOWED_KEYS = new ArrayList<>();
		OPPOSITE_KEYS = new HashMap<>();

		ALLOWED_KEYS.add(SWT.ARROW_UP);
		ALLOWED_KEYS.add(SWT.ARROW_RIGHT);
		ALLOWED_KEYS.add(SWT.ARROW_DOWN);
		ALLOWED_KEYS.add(SWT.ARROW_LEFT);

		OPPOSITE_KEYS.put(SWT.ARROW_UP, SWT.ARROW_DOWN);
		OPPOSITE_KEYS.put(SWT.ARROW_RIGHT, SWT.ARROW_LEFT);
		OPPOSITE_KEYS.put(SWT.ARROW_DOWN, SWT.ARROW_UP);
		OPPOSITE_KEYS.put(SWT.ARROW_LEFT, SWT.ARROW_RIGHT);
	}

	private final List<Point>			snake;
	private final List<SnakeListener>	listeners;
	private final Random				random;

	private Point						head;
	private Point						apple;
	private int							direction;
	private int							speed;

	private boolean						gameover;
	private boolean						pause;

	public SnakeCanvas(final Composite parent) {
		super(parent, SWT.NO_BACKGROUND);

		// Initialization
		snake = new ArrayList<>();
		listeners = new ArrayList<>();
		random = new Random();
		newGame();

		// Add listeners
		addPaintListener(this::draw);
		addListener(SWT.KeyDown, this::keyDown);
	}

	public void newGame() {
		// Clear old snake data
		snake.clear();

		// Setup initial game
		head = new Point(0, V_CENTER);
		apple = placeApple();
		direction = SWT.ARROW_RIGHT;
		speed = REFRESH_RATE;

		gameover = false;
		pause = false;

		// Create initial snake
		snake.add(head);
		for (int i = 1; i < INITIAL_SIZE; i++) {
			head = createHead();
			snake.add(head);
		}

		// Reset the score
		fireScoreChanged();

		// Animate
		animate();
	}

	private Point placeApple() {
		final Point point = new Point(random.nextInt(APPLE_LIMITS), random.nextInt(APPLE_LIMITS));

		if (snake.contains(point)) {
			return placeApple();
		}

		return point;
	}

	private void animate() {
		if (!isDisposed() && !pause && !gameover) {
			redraw();
			DISPLAY.timerExec(speed, this::animate);
		}
	}

	private void draw(final PaintEvent event) {
		// Create image and GC for double buffering
		final Image image = new Image(DISPLAY, PLAY_AREA, PLAY_AREA);
		final GC gc = new GC(image);

		// Paint brush settings
		gc.setBackground(COLOR_BLACK);
		gc.setForeground(COLOR_WHITE);
		gc.setFont(FONT_BOLD);

		// Make image as big as canvas and set background color
		gc.fillRectangle(0, 0, PLAY_AREA, PLAY_AREA);

		// Draw snake and apple
		gc.setBackground(COLOR_GREEN);
		drawPlayArea(gc);

		// Game over and Pause
		gc.setBackground(COLOR_RED);
		if (gameover) {
			gc.drawString("   Gameover   ", 112, 150);
		} else if (pause) {
			gc.drawString("   Paused   ", 120, 150);
		}

		// Display image on canvas
		event.gc.drawImage(image, 0, 0);

		// Dispose created resources
		image.dispose();
		gc.dispose();
	}

	private void drawPlayArea(final GC gc) {
		final Point newHead = createHead();
		final int width = SCALE - 1;

		// Add or replace new head
		if (newHead != null) {
			if (snake.contains(newHead) || newHead.x < 0 || newHead.x * SCALE >= PLAY_AREA || newHead.y < 0
					|| newHead.y * SCALE >= PLAY_AREA) {
				gameover = true;
			} else {
				head = newHead;
				snake.add(head);

				if (newHead.equals(apple)) {
					apple = placeApple();
					fireScoreChanged();
				} else {
					snake.remove(0);
				}
			}
		}

		// Snake
		for (final Point point : snake) {
			final int x = point.x * SCALE;
			final int y = point.y * SCALE;

			gc.fillRectangle(x, y, width, width);
		}

		// Apple
		gc.drawImage(AppImages.get(UISymbols.IMG_APPLE), apple.x * SCALE, apple.y * SCALE);
	}

	private Point createHead() {
		switch (direction) {
		case SWT.ARROW_UP:
			return new Point(head.x, head.y - 1);

		case SWT.ARROW_RIGHT:
			return new Point(head.x + 1, head.y);

		case SWT.ARROW_DOWN:
			return new Point(head.x, head.y + 1);

		case SWT.ARROW_LEFT:
			return new Point(head.x - 1, head.y);

		default:
			return null;
		}
	}

	private void fireScoreChanged() {
		final int score = snake.size() - INITIAL_SIZE;

		if (score != 0 && score % 5 == 0) {
			speed = speed - 20;
		}

		for (final SnakeListener listener : listeners) {
			listener.ate(score, speed);
		}
	}

	private void keyDown(final Event event) {
		final int keyCode = event.keyCode;

		if (!pause && !gameover && ALLOWED_KEYS.contains(keyCode) && OPPOSITE_KEYS.get(direction) != keyCode) {
			direction = keyCode;
		}
	}

	public void addSnakeListener(final SnakeListener listener) {
		listeners.add(listener);
	}

	public void removeSnakeListener(final SnakeListener listener) {
		listeners.remove(listener);
	}

	public void setPause(final boolean pause) {
		this.pause = pause;

		redraw();
		animate();
	}

	@Override
	public Point computeSize(final int wHint, final int hHint, final boolean changed) {
		return new Point(PLAY_AREA, PLAY_AREA);
	}
}
