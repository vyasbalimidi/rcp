package com.balimidi.parser.part;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.e4.core.di.annotations.Optional;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import com.balimidi.parser.model.Node;
import com.balimidi.parser.part.provider.DetailsLabelProvider;

/**
 * @author balimiv
 *
 */
public final class DetailsPart {
	private TableViewer viewer;

	@PostConstruct
	public void createPartControl(final Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		viewer = new TableViewer(parent, SWT.V_SCROLL | SWT.BORDER);
		final Table table = viewer.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		createTableColumns(table);

		viewer.setLabelProvider(new DetailsLabelProvider());
		viewer.setContentProvider(ArrayContentProvider.getInstance());
	}

	private void createTableColumns(final Table table) {
		final TableColumn colTag = new TableColumn(table, SWT.NONE);
		colTag.setResizable(true);
		colTag.setMoveable(true);
		colTag.setText("Tag");
		colTag.setWidth(120);

		final TableColumn colValue = new TableColumn(table, SWT.NONE);
		colValue.setResizable(true);
		colValue.setMoveable(true);
		colValue.setText("Value");
		colValue.setWidth(300);
	}

	@Inject
	public void setTodo(@Optional @Named(IServiceConstants.ACTIVE_SELECTION) final Node node) {
		if (node != null) {
			viewer.setInput(node.getChildren());
		}
	}
}
