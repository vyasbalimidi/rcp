package com.balimidi.parser.util;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.eclipse.core.runtime.Assert;

import com.balimidi.parser.constant.Symbols;
import com.balimidi.parser.model.Word;

/**
 * @author balimiv
 *
 */
public final class RecordContext {
	private RecordContext() {
		// Singleton
	}

	/**
	 * @param objects array of objects
	 * @return string representing the record
	 */
	public static String marshall(final Object... objects) {
		Assert.isNotNull(objects);
		final StringBuilder builder = new StringBuilder();

		for (final Object object : objects) {
			final Class<?> clazz = object.getClass();

			try {
				for (final Field field : clazz.getDeclaredFields()) {
					if (field.isAnnotationPresent(Word.class)) {
						final Object assignment = field.get(object);
						final String value = assignment != null ? assignment.toString() : Symbols.EMPTY;
						final int endIndex = field.getAnnotation(Word.class).end();

						if (value.length() >= endIndex) {
							final String truncated = value.substring(0, endIndex);
							builder.append(truncated);
						} else {
							builder.append(value);

							for (int index = value.length(); index < endIndex; index++) {
								builder.append(Symbols.SPACE);
							}
						}
					}

					// Insert new line after every sentence
					builder.append(Symbols.NEW_LINE);
				}
			} catch (IllegalArgumentException | IllegalAccessException exp) {
				// Do nothing
			}
		}

		return builder.toString();
	}

	public static <T> List<T> unmarshall(final String fileName, final Class<T> clazz) {
		final List<T> objects = new ArrayList<>();

		try (final Stream<String> stream = Files.lines(Paths.get(fileName))) {
			stream.forEach(line -> {
				try {
					final T sentence = clazz.newInstance();

					for (final Field field : clazz.getDeclaredFields()) {
						if (field.isAnnotationPresent(Word.class)) {
							final Word word = field.getAnnotation(Word.class);
							final String type = field.getAnnotatedType().getType().getTypeName();
							final String substring = line.substring(word.begin(), word.end());

							switch (type) {
							case "java.lang.String":
								field.set(sentence, substring);
								break;

							case "int":
								field.setInt(sentence, Integer.parseInt(substring));
								break;

							default:
								break;
							}
						}
					}

					objects.add(sentence);
				} catch (final Exception exp) {
					// Do nothing
				}

			});
		} catch (final Exception exp) {
			// Do nothing
		}

		return objects;
	}
}
