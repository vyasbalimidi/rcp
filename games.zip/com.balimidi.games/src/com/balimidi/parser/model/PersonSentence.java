package com.balimidi.parser.model;

/**
 * @author balimiv
 *
 */
@Sentence()
public final class PersonSentence {
	@Word(index = 0, length = 4)
	public String	id;

	@Word(index = 1, length = 20)
	public String	firstname;

	@Word(index = 2, length = 20)
	public String	lastname;

	@Word(index = 3, length = 2)
	public int		age;

	@Word(index = 4, length = 1)
	public String	gender;
}
