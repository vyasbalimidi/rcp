package com.balimidi.parser.model;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @author balimiv
 *
 */
public final class Node {
	private final String tag;
	private final Node parent;
	private final List<Node> children;
	
	private String value;

	public Node(final Node parent, final String tag) {
		this.parent = parent;
		this.tag = tag;
		this.children = new ArrayList<>();

		if (parent != null) {
			parent.children.add(this);
		}
	}

	public Node getParent() {
		return parent;
	}

	public String getTag() {
		return tag;
	}

	public String getValue() {
		return value;
	}

	public void setValue(final String value) {
		this.value = value;
	}

	public List<Node> getChildren() {
		return children;
	}

	public boolean hasChildren() {
		return !children.isEmpty();
	}

	@Override
	public String toString() {
		return MessageFormat.format("<{0}>{1}</{0}>", tag, value);
	}
}
