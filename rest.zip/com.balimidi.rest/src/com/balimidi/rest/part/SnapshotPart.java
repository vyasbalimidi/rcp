package com.balimidi.rest.part;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.e4.ui.workbench.modeling.ESelectionService;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Tree;

import com.balimidi.rest.model.Node;
import com.balimidi.rest.net.ClientJob;
import com.balimidi.rest.net.Net;
import com.balimidi.rest.part.listener.ILazyContent;
import com.balimidi.rest.part.listener.SnapshotCP;
import com.balimidi.rest.part.listener.SnapshotLP;

/**
 * @author balimiv
 *
 */
public final class SnapshotPart {
	private final List<String>	tried	= new ArrayList<>();
	private TreeViewer			viewer;
	@Inject
	private ESelectionService	service;

	@PostConstruct
	public void createPartControl(final Composite parent) {
		viewer = new TreeViewer(parent);

		final Tree tree = viewer.getTree();
		final ILazyContent<Node> lazyContent = getLazyContent();

		tree.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		viewer.setLabelProvider(new SnapshotLP());
		viewer.setContentProvider(new SnapshotCP(lazyContent));
		viewer.addSelectionChangedListener(event -> {

			final IStructuredSelection selection = viewer.getStructuredSelection();
			service.setSelection(selection.getFirstElement());
		});

		reload();
	}

	public void reload() {
		final ClientJob<Node> job = ClientJob.newRequest(Net.SNAPSHOT, Node.class);
		job.asyncGet(obj -> viewer.setInput(new Object[] { obj }));
	}

	private ILazyContent<Node> getLazyContent() {
		return new ILazyContent<Node>() {

			@Override
			public void load(final Node node) {
				final String param = "?occID=" + node.getOccID();
				final ClientJob<Node> job = ClientJob.newRequest(Net.SNAPSHOT + param, Node.class);

				job.asyncGet(obj -> {
					if (obj instanceof Node) {
						final Node nodeLatest = (Node) obj;
						final List<Node> children = nodeLatest.getChildren();
						tried.add(nodeLatest.getOccID());

						if (children != null && !children.isEmpty()) {
							node.setChildren(children);
							viewer.expandToLevel(node, 1);
						}
					}
				});
			}

			@Override
			public boolean canLoad(final Node element) {
				final Node node = element;
				return !tried.contains(node.getOccID());
			}
		};
	}
}