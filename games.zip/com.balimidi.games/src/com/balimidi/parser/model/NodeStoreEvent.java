package com.balimidi.parser.model;

/**
 * @author balimiv
 *
 */
public enum NodeStoreEvent {
	ADDED, REMOVED, UPDATED
}
