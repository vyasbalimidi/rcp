package com.balimidi.parser.job;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;

import com.balimidi.parser.constant.Symbols;
import com.balimidi.parser.model.Node;
import com.balimidi.parser.model.NodeStore;
import com.balimidi.parser.util.XmlParser;

/**
 * @author balimiv
 *
 */
public final class ParserJob extends Job {
	private final List<File> files;

	public ParserJob(final List<File> input) {
		super("Parsing XML files");
		files = new ArrayList<>(input);
	}

	@Override
	protected IStatus run(final IProgressMonitor monitor) {
		IStatus status = Status.OK_STATUS;
		final int totalWork = files.size() * 2 + 2;
		monitor.beginTask(getName(), totalWork);

		final List<String> failedPaths = new ArrayList<>();
		final List<String> processedFiles = NodeStore.processedFiles();

		for (final File file : files) {
			final String path = file.getAbsolutePath();
			monitor.subTask(path);
			monitor.worked(2);

			if (!processedFiles.contains(path)) {
				try {
					final Node node = XmlParser.parse(file);
					NodeStore.addNode(path, node);
				} catch (final Exception exp) {
					failedPaths.add(file.getName());
				}
			}

			monitor.worked(2);
		}
		monitor.done();

		if (!failedPaths.isEmpty()) {
			final String message = createErrorMessage(failedPaths);
			status = new Status(Status.WARNING, Symbols.PLUGIN_ID, message);
		}

		return status;
	}

	private String createErrorMessage(final List<String> failedPaths) {
		final StringBuilder buffer = new StringBuilder();

		buffer.append("Below files are probably corrupted or not XMLs:");
		buffer.append(Symbols.NEW_LINE);
		buffer.append(Symbols.NEW_LINE);

		for (final String path : failedPaths) {
			buffer.append(path);
			buffer.append(Symbols.NEW_LINE);
		}

		return buffer.toString();
	}
}
